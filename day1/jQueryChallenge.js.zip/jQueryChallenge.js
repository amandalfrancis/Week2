$(function() {
document.getElementById("add").onclick = function () {

     var text = document.getElementById("idea").value; //.value gets input values


    var li = "<li>" + text + "</li>";


    document.getElementById("list").appendChild(li);
}
});